import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Book } from '../book';

@Component({
  selector: 'app-books',
  templateUrl: './books.component.html'
})
export class BooksComponent {
  public books: Book[];

  public selectedBook: Book;
  private baseU: string;
  private httpC: HttpClient;


  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.baseU = baseUrl;
    this.httpC = http;

    http.get<Book[]>(baseUrl + 'api/Book/').subscribe(result => {
      this.books = result;
      console.log(result);
    }, error => console.error(error));
  }

  onSelect(book: Book): void {
    this.httpC.get<Book>(this.baseU+ './api/Book/' + book.id).subscribe(result => {
     this.selectedBook = result;
    }, error => console.error(error));
  }
  back(): void {
    this.selectedBook = null;
  }
}

//interface Book {
//  title: string;
//  author: string;

//  //dateFormatted: string;
//  //temperatureC: number;
//  //temperatureF: number;
//  //summary: string;
//}
