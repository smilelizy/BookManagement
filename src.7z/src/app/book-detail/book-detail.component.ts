import { Component, Inject, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Book } from "../book";

@Component({
  selector: 'app-book-detail',
  templateUrl: './book-detail.component.html'
})

export class BookDetailComponent implements OnInit{
  @Input() book: Book;
  constructor() { }
  ngOnInit() {
  }
}

//interface Book {
//  title: string;
//  author: string;

//  //dateFormatted: string;
//  //temperatureC: number;
//  //temperatureF: number;
//  //summary: string;
//}
