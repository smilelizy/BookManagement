import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Author } from '../author';

@Component({
  selector: 'app-authors',
  templateUrl: './authors.component.html'
})
export class AuthorsComponent {
  public authors: Author[];

  public selectedAuthor: Author;
  private baseU: string;
  private httpC: HttpClient;


  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    this.baseU = baseUrl;
    this.httpC = http;

    http.get<Author[]>(baseUrl + 'api/Author/').subscribe(result => {
      this.authors = result;
    }, error => console.error(error));
  }


  onSelect(author: Author): void {
    this.httpC.get<Author>(this.baseU + './api/Author/' + author.id).subscribe(result => {
      this.selectedAuthor = result;
    }, error => console.error(error));
  }

  back(): void {
    this.selectedAuthor = null;
  }

}
