import { Component, Inject, OnInit, Input } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Author } from "../author";


@Component({
  selector: 'app-author-detail',
  templateUrl: './author-detail.component.html'
})

export class AuthorDetailComponent implements OnInit {
  @Input() author: Author;
  constructor() { }
  ngOnInit() {
  }
}
