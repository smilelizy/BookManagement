"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Book = /** @class */ (function () {
    function Book() {
    }
    return Book;
}());
exports.Book = Book;
//# sourceMappingURL=book.js.map